package principio4_I;

/**
 *
 * @author Sebastian
 */
public class Principal {

    public static void main(String[] args) {
        Leon obj = new Leon();
        obj.nacimiento_mama();
        obj.sound();
        obj.sleep();
    }

}
