package principio4_I;

/**
 *
 * @author Sebastian
 */
public interface Mamifero {

    public void nacimiento_mama();
    
}
