package principio5_D;

/**
 *
 * @author Sebastian
 */
public class Principal {

    /*
     * 1. Principio de dependencias POO = Inyección de dependencias Dependencia =
     * 2. Objeto auto y objeto gasolinera
     * 3. Es necesario hacer uso de usa gasolinería para abastecerlo
     * 4. Para que funcione correctamente la dependencia: Gasolinería debe tener gasolina
     * 5. DEPENDENCIA FUERTEMENTE ACOPLADA = Objeto carro para andar depende del objeto gasolina funcionando
     * @param args
     */
    public static void main(String[] args) {

    }
}
