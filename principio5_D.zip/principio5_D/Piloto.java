package principio5_D;

/**
 *
 * @author Sebastian
 */
public interface Piloto {

    public void pilorear();
}
